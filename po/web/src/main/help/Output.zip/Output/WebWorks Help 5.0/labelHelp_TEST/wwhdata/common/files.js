function  WWHBookData_Files(P)
{
P.fA("Registering New Trials","register.1.1.html");
P.fA("Registering Non-Proprietary Trials in the CTRP Registration Site","register.1.2.html");
P.fA("Editing Trial Details","register.1.3.html");
P.fA("Printing Trial Information","register.1.4.html");
P.fA("Completing the Trial Identifiers Section","register.1.5.html");
P.fA("Completing the Trial Details Section","register.1.6.html");
P.fA("Completing the Lead Organization/Principal Investigator Section","register.1.7.html");
P.fA("Completing the Sponsor/Responsible Party Section","register.1.8.html");
P.fA("Completing the Summary 4 Information Section","register.1.9.html");
P.fA("Completing the NIH Grant Information Section","register.1.10.html");
P.fA("Completing the Trial Status/Dates Section","register.1.11.html");
P.fA("Completing the IND/IDE Information Section","register.1.12.html");
P.fA("Registering IND Trials","register.1.13.html");
P.fA("Registering IDE Trials","register.1.14.html");
P.fA("Completing the Trial Related Documents Section","register.1.15.html");
P.fA("Registering Proprietary Trials in the CTRP Registration Site","register.1.16.html");
P.fA("Completing the Trial Identification Section for Proprietary Trials","register.1.17.html");
P.fA("Completing the Trial Details Section for Proprietary Trials","register.1.18.html");
P.fA("Completing Summary 4 Information for Proprietary Trials","register.1.19.html");
P.fA("Completing the Trial Status/Dates Section for Proprietary Trials","register.1.20.html");
P.fA("Completing the Trial Related Documents Section for Proprietary Trials","register.1.21.html");
P.fA("Registering Organizations","register.1.22.html");
P.fA("Searching for Registered Organizations","register.1.23.html");
P.fA("Adding Organizations","register.1.24.html");
P.fA("Registering Persons","register.1.25.html");
P.fA("Searching for Principal Investigators","register.1.26.html");
P.fA("Adding Principal Investigators","register.1.27.html");
P.fA("Registering Multiple Trials in a Batch","register.1.28.html");
P.fA("Data Requirements for Batch Uploads","register.1.29.html");
}
