function FileData_Pairs(x)
{
x.t("curating","organization");
x.t("managing","health");
x.t("managing","organizations");
x.t("care","facilities");
x.t("organization","records");
x.t("health","care");
x.t("records","assigning");
x.t("facilities","managing");
x.t("organizations","curating");
x.t("assigning","roles");
x.t("roles","managing");
}
