function FileData_Pairs(x)
{
x.t("curating","organization");
x.t("managing","oversight");
x.t("managing","organizations");
x.t("organization","records");
x.t("commitees","managing");
x.t("records","assigning");
x.t("oversight","commitees");
x.t("organizations","curating");
x.t("assigning","roles");
x.t("roles","managing");
}
