function FileData_Pairs(x)
{
x.t("lead","organization");
x.t("amendment","number");
x.t("organization","part");
x.t("part","amended");
x.t("metadata","definitions");
x.t("number","amendment");
x.t("number","metadata");
x.t("number","number");
x.t("number","assigned");
x.t("assigned","amended");
x.t("amended","protocol");
x.t("protocol","lead");
x.t("protocol","document");
x.t("definitions","amendment");
}
