function FileData_Pairs(x)
{
x.t("curating","persons");
x.t("managing","persons");
x.t("managing","roles");
x.t("persons","curating");
x.t("persons","managing");
x.t("contacts","managing");
x.t("contacts","maganing");
x.t("organizational","contacts");
x.t("maganing","organizational");
x.t("roles","maganing");
}
