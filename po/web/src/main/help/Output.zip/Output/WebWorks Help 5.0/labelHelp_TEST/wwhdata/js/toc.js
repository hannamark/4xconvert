function  WWHBookData_AddTOCEntries(P)
{
var A=P.fN("Registering New Trials","0");
var B=A.fN("Registering Non-Proprietary Trials in the CTRP Registration Site","1");
var C=B.fN("Editing Trial Details","2");
C=B.fN("Printing Trial Information","3");
C=B.fN("Completing the Trial Identifiers Section","4");
C=B.fN("Completing the Trial Details Section","5");
C=B.fN("Completing the Lead Organization/Principal Investigator Section","6");
C=B.fN("Completing the Sponsor/Responsible Party Section","7");
C=B.fN("Completing the Summary 4 Information Section","8");
C=B.fN("Completing the NIH Grant Information Section","9");
C=B.fN("Completing the Trial Status/Dates Section","10");
C=B.fN("Completing the IND/IDE Information Section","11");
var D=C.fN("Registering IND Trials","12");
D=C.fN("Registering IDE Trials","13");
C=B.fN("Completing the Trial Related Documents Section","14");
B=A.fN("Registering Proprietary Trials in the CTRP Registration Site","15");
C=B.fN("Completing the Trial Identification Section for Proprietary Trials","16");
C=B.fN("Completing the Trial Details Section for Proprietary Trials","17");
C=B.fN("Completing Summary 4 Information for Proprietary Trials","18");
C=B.fN("Completing the Trial Status/Dates Section for Proprietary Trials","19");
C=B.fN("Completing the Trial Related Documents Section for Proprietary Trials","20");
B=A.fN("Registering Organizations","21");
C=B.fN("Searching for Registered Organizations","22");
C=B.fN("Adding Organizations","23");
B=A.fN("Registering Persons","24");
C=B.fN("Searching for Principal Investigators","25");
C=B.fN("Adding Principal Investigators","26");
B=A.fN("Registering Multiple Trials in a Batch","27");
C=B.fN("Data Requirements for Batch Uploads","28");
}
