function FileData_Pairs(x)
{
x.t("managing","organization");
x.t("managing","organizations");
x.t("instructions","managing");
x.t("organization","records");
x.t("provides","instructions");
x.t("section","provides");
x.t("organizations","managing");
x.t("organizations","section");
}
