function FileData_Pairs(x)
{
x.t("curating","persons");
x.t("persons","curating");
x.t("persons","managing");
x.t("persons","change");
x.t("managing","persons");
x.t("change","requests");
}
