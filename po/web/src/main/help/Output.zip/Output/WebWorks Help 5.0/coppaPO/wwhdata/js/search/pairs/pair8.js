function FileData_Pairs(x)
{
x.t("tables","navigating");
x.t("tables","getting");
x.t("navigating","records");
x.t("navigating","p/o");
x.t("getting","started");
x.t("records","tables");
x.t("started","nci");
x.t("portal","navigating");
x.t("p/o","curation");
x.t("curation","portal");
x.t("person/organization","curation");
x.t("shared","person/organization");
x.t("nci","shared");
}
