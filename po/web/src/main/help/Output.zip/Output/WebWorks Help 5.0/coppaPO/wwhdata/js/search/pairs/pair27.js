function FileData_Pairs(x)
{
x.t("managing","organizations");
x.t("organization","records");
x.t("ctep","organization");
x.t("records","managing");
x.t("records","importing");
x.t("importing","ctep");
x.t("organizations","importing");
}
