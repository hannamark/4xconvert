function FileData_Pairs(x)
{
x.t("curating","organization");
x.t("managing","organizations");
x.t("managing","research");
x.t("organization","records");
x.t("records","assigning");
x.t("organizations","curating");
x.t("organizations","managing");
x.t("research","organizations");
x.t("assigning","roles");
x.t("roles","managing");
}
