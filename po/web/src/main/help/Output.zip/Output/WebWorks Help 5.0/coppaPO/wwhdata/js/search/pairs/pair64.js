function FileData_Pairs(x)
{
x.t("study","product");
x.t("method","tested");
x.t("refers","nature");
x.t("nature","investigation");
x.t("type","refers");
x.t("type","trial");
x.t("type","metadata");
x.t("product","procedure");
x.t("trial","type");
x.t("metadata","definitions");
x.t("represents","clinical");
x.t("procedure","method");
x.t("investigation","represents");
x.t("definitions","trial");
x.t("clinical","study");
}
