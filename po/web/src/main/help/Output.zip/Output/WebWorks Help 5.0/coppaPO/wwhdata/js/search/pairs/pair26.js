function FileData_Pairs(x)
{
x.t("curating","organization");
x.t("managing","organizations");
x.t("deleting","organizations");
x.t("organization","records");
x.t("records","deleting");
x.t("(nullifying)","managing");
x.t("(nullifying)","deleting");
x.t("organizations","curating");
x.t("organizations","(nullifying)");
}
