function FileData_Pairs(x)
{
x.t("provides","values");
x.t("metadata","definitions");
x.t("metadata","associated");
x.t("section","provides");
x.t("values","definitions");
x.t("definitions","metadata");
x.t("definitions","section");
x.t("associated","clinical");
x.t("clinical","trials");
}
