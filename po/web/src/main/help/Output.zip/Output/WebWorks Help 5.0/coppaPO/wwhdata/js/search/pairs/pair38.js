function FileData_Pairs(x)
{
x.t("curating","persons");
x.t("persons","curating");
x.t("persons","deleting");
x.t("persons","(nullifying)");
x.t("managing","persons");
x.t("deleting","persons");
x.t("(nullifying)","managing");
x.t("(nullifying)","deleting");
}
