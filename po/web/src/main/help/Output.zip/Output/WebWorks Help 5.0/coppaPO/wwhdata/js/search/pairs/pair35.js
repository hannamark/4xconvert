function FileData_Pairs(x)
{
x.t("curating","persons");
x.t("managing","persons");
x.t("managing","health");
x.t("managing","roles");
x.t("persons","curating");
x.t("persons","managing");
x.t("providers","managing");
x.t("care","providers");
x.t("health","care");
x.t("roles","managing");
}
