function FileData_Pairs(x)
{
x.t("managing","persons");
x.t("managing","person");
x.t("persons","managing");
x.t("persons","section");
x.t("instructions","managing");
x.t("provides","instructions");
x.t("person","records");
x.t("section","provides");
}
