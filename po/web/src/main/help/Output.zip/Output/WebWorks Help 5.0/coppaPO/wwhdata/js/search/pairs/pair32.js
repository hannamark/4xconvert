function FileData_Pairs(x)
{
x.t("searching","duplicate");
x.t("curating","persons");
x.t("managing","persons");
x.t("persons","searching");
x.t("persons","curating");
x.t("duplicate","records");
x.t("records","searching");
x.t("records","managing");
}
