function FileData_Pairs(x)
{
x.t("example","moitessier");
x.t("study","example");
x.t("responsible","aspects");
x.t("aspects","conduct");
x.t("metadata","definitions");
x.t("investigator","responsible");
x.t("investigator","metadata");
x.t("investigator","investigator");
x.t("investigator","principal");
x.t("conduct","study");
x.t("principal","investigator");
x.t("moitessier","bernard");
x.t("definitions","principal");
}
