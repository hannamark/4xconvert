function  WWHBookData_MatchTopic(P)
{
var C=null;
if(P=="tooltip_ct.gov_xml")C="register.1.2.html#1181815";
if(P=="edit_trial")C="register.1.3.html#1080763";
if(P=="tooltip_trial_id")C="register.1.5.html#1182358";
if(P=="tooltip_phases")C="register.1.6.html#1078117";
if(P=="tooltip_lead_org")C="register.1.7.html#1183079";
if(P=="tooltip_principal_invest")C="register.1.7.html#1078324";
if(P=="tooltip_sponsor")C="register.1.8.html#1106975";
if(P=="tooltip_responsible__party")C="register.1.8.html#1167748";
if(P=="tooltip_summary_4")C="register.1.9.html#1078466";
if(P=="tooltip_summary_4_fund")C="register.1.9.html#1184258";
if(P=="submit_trial_proprietary")C="register.1.16.html#1100834";
return C;
}
