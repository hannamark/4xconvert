function FileData_Pairs(x)
{
x.t("curating","persons");
x.t("managing","persons");
x.t("managing","roles");
x.t("managing","clinical");
x.t("persons","curating");
x.t("persons","managing");
x.t("staff","managing");
x.t("research","staff");
x.t("roles","managing");
x.t("clinical","research");
}
