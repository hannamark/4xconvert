function FileData_Pairs(x)
{
x.t("curating","organization");
x.t("managing","identified");
x.t("managing","organizations");
x.t("pertians","roles");
x.t("organization","pertians");
x.t("organization","records");
x.t("identified","organizations");
x.t("records","assigning");
x.t("organizations","curating");
x.t("organizations","managing");
x.t("organizations","scoper");
x.t("scoper","organization");
x.t("assigning","roles");
x.t("roles","managing");
}
