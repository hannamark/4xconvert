function FileData_Pairs(x)
{
x.t("persons","managing");
x.t("persons","deleting");
x.t("persons","creating");
x.t("persons","(nullifying)");
x.t("persons","assigning");
x.t("managing","persons");
x.t("deleting","persons");
x.t("new","persons");
x.t("creating","new");
x.t("assigning","roles");
x.t("roles","persons");
}
