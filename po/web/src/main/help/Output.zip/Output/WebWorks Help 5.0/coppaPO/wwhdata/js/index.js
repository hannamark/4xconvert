function  WWHBookData_AddIndexEntries(P)
{
var A=P.fA("A",null,null,"002");
var B=A.fA("Application Support",new Array("39#1083797"));
A=P.fA("D",null,null,"002");
B=A.fA("data monitoring commitee",new Array("38#1092976"));
A=P.fA("L",null,null,"002");
B=A.fA("logging out",new Array("8#1092699"));
B=A.fA("Logout link",new Array("8#1093245"));
A=P.fA("N",null,null,"002");
B=A.fA("NCICB Application Support",new Array("39#1083797"));
A=P.fA("O",null,null,"002");
B=A.fA("Online help");
var C=B.fA("locating topics of interest",new Array("1#1105356"));
C=B.fA("printing",new Array("1#1105387"));
C=B.fA("using navigation tools",new Array("2"));
B=A.fA("Online help, using",new Array("1"));
A=P.fA("P",null,null,"002");
B=A.fA("Principal Investigator",new Array("37#1135751"));
A=P.fA("S",null,null,"002");
B=A.fA("Section 801 trials",new Array("37#1135810"));
A=P.fA("U",null,null,"002");
B=A.fA("Using online help",new Array("1","1"));
}

function  WWHBookData_MaxIndexLevel()
{
  return 3;
}
