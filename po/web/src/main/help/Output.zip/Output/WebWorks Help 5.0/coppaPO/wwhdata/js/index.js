function  WWHBookData_AddIndexEntries(P)
{
var A=P.fA("A",null,null,"002");
var B=A.fA("Application Support",new Array("41#1083557"));
A=P.fA("B",null,null,"002");
B=A.fA("Becoming a registered user",new Array("1"));
A=P.fA("D",null,null,"002");
B=A.fA("data monitoring commitee",new Array("40#1092976"));
A=P.fA("L",null,null,"002");
B=A.fA("logging out");
var C=B.fA("TCGA Analysis",new Array("10#1092699"));
B=A.fA("Logout link",new Array("6#1088468","10#1092703"));
A=P.fA("N",null,null,"002");
B=A.fA("NCICB Application Support",new Array("41#1083557"));
A=P.fA("O",null,null,"002");
B=A.fA("Online help");
C=B.fA("locating topics of interest",new Array("1#1105356"));
C=B.fA("printing",new Array("1#1105387"));
C=B.fA("using navigation tools",new Array("2"));
B=A.fA("Online help, using",new Array("1"));
A=P.fA("P",null,null,"002");
B=A.fA("Principal Investigator",new Array("39#1135751"));
A=P.fA("R",null,null,"002");
B=A.fA("Register/Login link",new Array("6#1089218"));
B=A.fA("Registration",new Array("1"));
A=P.fA("S",null,null,"002");
B=A.fA("Section 801 trials",new Array("39#1135810"));
A=P.fA("T",null,null,"002");
B=A.fA("TCGA Analysis");
C=B.fA("logging out",new Array("10#1092699"));
A=P.fA("U",null,null,"002");
B=A.fA("User guide link",new Array("6#1092049"));
B=A.fA("Using online help",new Array("1"));
}

function  WWHBookData_MaxIndexLevel()
{
  return 3;
}
